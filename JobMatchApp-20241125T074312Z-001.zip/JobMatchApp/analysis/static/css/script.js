document.addEventListener("DOMContentLoaded", () => {
    console.log("Welcome to JobFit Pro!");
    // Future functionality can be added here
});


